There are all python files, include part1, part2 and part3

Part 1: Nearest Neighbour Method
1.k nearest neighbour.py
2.K-mean.py

Part2: Decision Tree Learning Algorithm
Decision Tree Learning.py(import copy)

Part3: Perceptron 
peceptron.py(import random)
test1,
test2,
test3,
test4,
test5,
test6.

To compile and execute the program environment:

-Pycharm 2018.3.5  (Python 3.6)  jre:1.8
- import the python file (such as import random,import copy)


* the data files are in the code files 
