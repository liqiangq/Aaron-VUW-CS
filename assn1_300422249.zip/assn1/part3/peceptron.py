"""
Assignment 1  perceptron
Author: Aaron Lee
Student Id: 300422249
class: Feature
test file: test1---test6
"""

import random
random.seed(1)

class Feature:
    """Represents a feature as perceptron."""
    def __init__(self, row, col, sgn):
        self.row = row
        self.col = col
        self.sgn = sgn

    def __str__(self):
        """ a string representation of this Feature"""
        return "(row: {0}, col: {1}, sgn: {2})".format(
        self.row, self.col, self.sgn)


def initial_features():
    """Get the list of 50 random features"""
    print("Random features are:")
    feature_list = []
    for i in range(50):
        row = []
        col = []
        sgn = []
        for j in range(4):
            row.append(random.randint(0, 9))
            col.append(random.randint(0, 9))
            sgn.append(random.randint(0, 1))
        feature = Feature(row, col, sgn)
        feature_list.append(feature)
        print(feature)
    return feature_list


def initial_weights():
    """initialize weight   random 50 weights """
    print("Initial weights set are:")
    weight_list = []
    for i in range(51):
        weight_list.append(random.uniform(0, 1))
    print(weight_list)
    return weight_list


def image_process(filename):
    """Process the image data"""
    inputfile = open(filename)
    data = inputfile.readlines()
    inputfile.close()
    image_list = []
    for i in range(100):
        image = []
        class_name = data[i * 5 + 1].split()
        temp = list(data[i * 5 + 3].replace("\n", "") + data[i * 5 + 4].replace("\n", ""))
        for j in range(10):
            image.append(temp[(j * 10): ((j * 10) + 10)])
        image_list.append((image, class_name))
    return image_list


def construct_tran_vector(image_list, feature_list):
    """construct feature vector for input"""
    input_list = []
    for image in image_list:
        vector = [1]
        for feature in feature_list:
            value = get_feature_value(image[0], feature)
            vector.append(value)
        if image[1][0] == "#X":
            y = 1
        else:
            y = 0
        input_list.append((vector, y))
    return input_list


def get_feature_value(image, feature):
    """calculate value for each feature on image"""
    summation = 0

    for i in range(4):
        a = feature.row[i]
        b = feature.col[i]
        if int(image[a][b]) == feature.sgn[i]:
            summation += 1
    if summation >= 3:
        value = 1
    else:
        value = 0
    return value


def perceptron_processing(input_list, weight_list, m):
    """Get the result of weight_list and print weight_list"""
    k = 0
    hits = 0
    while k > m or hits < 100:
        hits = 0
        for vector in input_list:
            true_label = vector[1]
            summation = 0
            for i in range(51):
                summation += vector[0][i] * weight_list[i]
            if summation > 0:
                predict = 1
            else:
                predict = 0
            if predict == true_label:
                hits += 1
            else:
                for i in range(51):
                    weight_list[i] += (vector[1] - predict) * vector[0][i]
        k += 1
    print("After {} times learning, the matched number of image is {}:".format(k, hits))
    print("Accuracy: {:.2f}".format(hits/100))
    print("Final weight set is:")
    print(weight_list)
    return weight_list


def get_classification(filename, feature_list,  weight_list):
    """Get the classification of testdata and print"""
    inputfile = open(filename)
    data = inputfile.readlines()
    inputfile.close()
    image_list = []
    image = []
    class_name = data[1].split()

    temp = list(data[3].replace("\n", "") + data[4].replace("\n", ""))
    for j in range(10):
        image.append(temp[(j * 10): ((j * 10) + 10)])
    image_list.append((image, class_name))
    x = construct_tran_vector(image_list, feature_list)
    image = x[0][0]
    total = 0
    for i in range(51):
        total += image[i] * weight_list[i]
    if total > 0:
        classification = "#X"
    else:
        classification = "#0"

    if class_name[0] == classification:
        print(" from file: "+filename+" out: Correct!")
    else:
        print(" from file: "+filename+" out: Incorrect!")


def main():

    # 1. load the set of images from the data file
    image_list = image_process("image.data")

    # 2. initial  weight_list and feature_list
    weight_list = initial_weights()
    feature_list = initial_features()

    # 3. construct a perceptron that uses the features as inputs
    input_list = construct_tran_vector(image_list, feature_list)

    # 4. train the perceptron on the images (least 100 times) eg.1000
    perceptron_processing(input_list, weight_list, 1000)

    # 5. report on the number of training cycles to convergence(6 test files)
    for i in range(1,7):
      get_classification("test"+str(i), feature_list, weight_list)


if __name__ == "__main__":
  main()