"""
Assignment 1  Decision tree leaarning
Author: Aaron Lee
Student Id: 300422249
"""

import copy


class Node:
    """Represents nodes in DT"""
    def __init__(self, bestatt, left, right):
        self.bestAtt = bestatt
        self.left = left
        self.right = right

    def report(self, indent):
        """Output the report"""
        print("{}{} = True\n". format(indent, self.bestAtt))
        self.left.report(indent+"    ")
        print("{}{} = False\n".format(indent, self.bestAtt))
        self.right.report(indent + "    ")


class Leaf:
    """Represents leaf in the DT"""
    def __init__(self, label, prob, ins_left):
        self.label = label
        self.prob = str(prob)
        self.ins_left = ins_left

    def report(self, indent):
        """Output the report"""
        print("{}Class {}, prob = {}, /{}\n".format(indent, self.label, self.prob, self.ins_left))


def training_process(filename):
    """Process the training data"""
    training_set = open(filename)
    training_data_line = training_set.readlines()
    training_set.close()
    class_list = training_data_line[0].split()
    attr_list = training_data_line[1].split()
    training_list = []
    count = 0
    for data_line in training_data_line[2:]:
        data_line.replace("\n", "")
        data = data_line.split()
        class_name = data[0]
        if class_name == class_list[0]:
            count += 1
        temp_list = data[1:]
        data_dict = {}
        length = len(temp_list)
        for i in range(length):
            data_dict[attr_list[i]] = temp_list[i]
        training_list.append((class_name, data_dict))
    a = float(count) / float(len(training_list))
    b = 1 - a
    half_total = len(training_list) / 2
    if count > half_total:
        most_prob = class_list[0]
        return (training_list, attr_list, class_list, most_prob, a)
    else:
        most_prob = class_list[1]
        return (training_list, attr_list, class_list, most_prob, b)


def calculate_impurity(instance_list, attr_list, class_list):
    """function to calculate impurity, find bestAtt, bestInstsTrue, bestInstsFalse """
    impurity_dict = {}
    temp = {}
    temp[0]=99;

    for attr in attr_list:
        true_set = []
        false_set = []
        for instance in instance_list:
            if instance[1][attr] == "true":
                true_set.append(instance)
            else:
                false_set.append(instance)
        true_weight = float(len(true_set)) / float(len(instance_list))
        false_weight = float(len(false_set)) / float(len(instance_list))

        true_count = 0
        false_count = 0
        if true_weight == 0:
            true_prob = 0
        else:
            for obj in true_set:
                if obj[0] == class_list[0]:
                    true_count += 1
            m = float(true_count) / float(len(true_set))
            n = 1 - m
            true_prob = true_weight * (2 * m * n) / (m + n) ** 2
        if false_weight == 0:
            false_prob = 0
        else:
            for obj in false_set:
                if obj[0] == class_list[0]:
                    false_count += 1

            m = float(false_count) / float(len(false_set))
            n = 1 - m
            false_prob = false_weight * (2 * m * n) / (m + n) ** 2
        impurity = true_prob + false_prob
        impurity_dict[attr] = (impurity, true_set, false_set)
        if temp[0] >= impurity:
            temp[0] = impurity
            temp[1] = attr
            temp[2] = true_set
            temp[3] = false_set

    bestAtt = temp[1]
    bestInstsTrue = temp[2]
    bestInstsFalse = temp[3]
    return(bestAtt, bestInstsTrue, bestInstsFalse)


def detect_pure(instance_list, class_list):
    """detect if instances are pure"""
    count = 0
    for instance in instance_list:
        if instance[0] == class_list[0]:
            count += 1
    if count == len(instance_list):
        return (0, class_list[0], len(instance_list))
    elif count == 0:
        return (0, class_list[1], len(instance_list))
    else:
        if count >= len(instance_list) - count:
            label = class_list[0]
            prob = float(count) / float(len(instance_list))
            ins_left = count
        else:
            label = class_list[1]
            prob = 1 - float(count) / float(len(instance_list))
            ins_left = len(instance_list) - count
        return(prob, label, ins_left)


def BuildTree(instance_list, attr_list, class_list, most_prob, prob):
    """function takes two arguments to build up decision tree"""
    # 1. if instances is empty
    if len(instance_list) == 0:
        return Leaf(most_prob, prob, 0)
    pure, label, ins_left = detect_pure(instance_list, class_list)

    # 2. if instances are pure
    if pure == 0:
        return Leaf(label, 1, ins_left)

    # 3. if attributes is empty else find best attribute
    if len(attr_list) == 0:
        prob, label, ins_left = detect_pure(instance_list, class_list)
        return Leaf(label, prob, ins_left)
    else:
        bestAtt, bestInstsTrue, bestInstsFalse = calculate_impurity(instance_list, attr_list, class_list)
        new_attr_list = copy.copy(attr_list)
        new_attr_list.remove(bestAtt)
        left = BuildTree(bestInstsTrue, new_attr_list, class_list, most_prob, prob)
        right = BuildTree(bestInstsFalse, new_attr_list, class_list, most_prob, prob)
    return Node(bestAtt, left, right)


def classifier(filename, tree):
    """a classifier based on DT tree"""
    test_set = open(filename)
    test_data_line = test_set.readlines()
    test_set.close()
    class_list = test_data_line[0].split()
    attr_list = test_data_line[1].split()
    test_list = []
    count = 0
    for data_line in test_data_line[2:]:
        data_line.replace("\n", "")
        data = data_line.split()
        class_name = data[0]
        if class_name == class_list[0]:
            count += 1
        temp_list = data[1:]
        data_dict = {}
        length = len(temp_list)
        for i in range(length):
            data_dict[attr_list[i]] = temp_list[i]
        test_list.append((class_name, data_dict))
    total = len(test_list)
    half_total = total / 2
    if count > half_total:
        baseline = class_list[0]
        other = class_list[1]
    else:
        baseline = class_list[1]
        other = class_name[0]
    node = tree
    correct = 0
    baselinecorrect = 0
    for instance in test_list:
        while isinstance(node, Node):
            if instance[1][node.bestAtt] == 'true':
                node = node.left
            else:
                node = node.right
        if instance[0] == node.label:
            correct += 1
            if node.label == baseline:
                baselinecorrect += 1
        node = tree
    accuracy = float(correct) / float(len(test_list)) * 100
    baseline_accuracy = float(baselinecorrect) / float(count) * 100
    print("Read: {} instances".format(total))
    print("Baseline class is: " + baseline)
    print("{}: {} correct out of {}".format(baseline, baselinecorrect, count))
    print("{}: {} correct out of {}".format(other, correct - baselinecorrect, total - count))
    print("Accuracy: {:.2f}%".format(accuracy))
    print("Baseline Accuracy: {:.2f}%".format(baseline_accuracy))
    return accuracy

def main():
    """ Get the job done """

    # 1. load training_data from the data file
    training_file = "hepatitis-training.dat"
    instance_list, attr_list, class_list, most_prob, prob = training_process(training_file)

    # 2. run buildTree
    tree = BuildTree(instance_list, attr_list, class_list, most_prob, prob)

    # 3. print tree
    print("The learned decision tree classifier is")
    tree.report("    ")
    print("The learned decision tree is applied to training data")
    classifier("hepatitis-training.dat", tree)
    print("The learned decision tree is applied to test data")
    classifier("hepatitis-test.dat", tree)
    accuracy = 0

    # 4. load train data and test data from file
    for i in range(1,11):
        print("run" + str(i))
        if i == 10:
            trainfilename = "hepatitis-training-run" + str(i) + ".dat"
            testfilename = "hepatitis-test-run" + str(i) + ".dat"
        else:
            trainfilename = "hepatitis-training-run0" + str(i) + ".dat"
            testfilename = "hepatitis-test-run0" + str(i) + ".dat"

        # 5. load train data from file
        instance_list, attr_list, class_list, most_prob, prob = training_process(trainfilename)

        # 6. BuildTree form instance_list, attr_list, class_list, most_prob, prob
        tree = BuildTree(instance_list, attr_list, class_list, most_prob, prob)

        # 7. classifier
        accuracy += classifier(testfilename, tree)
    average_accuracy = accuracy / 10
    print("Average accuracy: {:.2f}%".format(average_accuracy))

# ==================================================================

if __name__ == "__main__":
  main()