"""
Assignment 1  K Mean Method(optional)
Author: Aaron Lee
Student Id: 300422249
"""

import random
random.seed(1)

def load_data(filename):
     #  Data processing, make the training.txt and test.txt easy to use

     # training data processing
    training_set = open(filename)
    training_data_line = training_set.readlines()

    training_data_line.pop(-1)
    training_set.close()
    training_data_list = []
    label = "initial"
    temp1 = []
    temp2 = []
    temp3 = []
    temp4 = []

    for line in training_data_line:
        line.replace("\n", "")
        train_data = line.split(',')

        a1 = float(train_data[0])
        a2 = float(train_data[1])
        a3 = float(train_data[2])
        a4 = float(train_data[3])

        training_data_list.append([[a1, a2, a3, a4], label])
        temp1.append(a1)
        temp2.append(a2)
        temp3.append(a3)
        temp4.append(a4)
    r1 = max(temp1) - min(temp1)
    r2 = max(temp2) - min(temp2)
    r3 = max(temp3) - min(temp3)
    r4 = max(temp4) - min(temp4)
    ranging = [r1, r2, r3, r4]
    return (training_data_list, ranging)


def k_mean_cluster(data_list, ranging, clustercenter1, clustercenter2, clustercenter3, count):
     #  k mean clustering method
    count += 1
    data_list = cluster_method(data_list, clustercenter1, clustercenter2, clustercenter3, ranging)
    newcenter1, newcenter2, newcenter3 = calculate_center(data_list)
    if (newcenter1, newcenter2, newcenter3) == (clustercenter1, clustercenter2, clustercenter3):
        print("The results after {} times and after {} times are same, so the final center is:".format(count - 1, count))
        print("clustercenter1:", clustercenter1)
        print("clustercenter2:", clustercenter2)
        print("clustercenter3:", clustercenter3)
        for instance in data_list:
            print(instance)
        return (clustercenter1, clustercenter2, clustercenter3)
    else:
        print("results after {} times".format(count))
        print("clustercenter1:", newcenter1)
        print("clustercenter2:", newcenter2)
        print("clustercenter3:", newcenter3)
        k_mean_cluster(data_list, ranging, newcenter1, newcenter2, newcenter3, count)


def cluster_method(data_list, clustercenter1, clustercenter2, clustercenter3, ranging):
    #  give cluster for each instance
    for data in data_list:
        d_cluster1 = distance_measure(data[0], clustercenter1, ranging[0], ranging[1], ranging[2], ranging[3])
        d_cluster2 = distance_measure(data[0], clustercenter2, ranging[0], ranging[1], ranging[2], ranging[3])
        d_cluster3 = distance_measure(data[0], clustercenter3, ranging[0], ranging[1], ranging[2], ranging[3])
        temp = min(d_cluster1, d_cluster2, d_cluster3)
        if temp == d_cluster1:
            data[1] = 'cluster1'
        elif temp == d_cluster2:
            data[1] = 'cluster2'
        else:
            data[1] = 'cluster3'
    return data_list


def distance_measure(v1, v2, r1, r2, r3, r4):
     # calculate the distance between test object with every training objects
    distance = (((v1[0] - v2[0])/r1)**2 + ((v1[1] - v2[1])/r2)**2 + ((v1[2] - v2[2])/r3)**2 +((v1[3] - v2[3]) / r4) ** 2) ** 0.5
    return distance


def calculate_center(data_list):
     #  calculate centers of three clusters
    cluster1 = []
    cluster2 = []
    cluster3 = []
    for data in data_list:
        if data[1] == 'cluster1':
            cluster1.append(data)
        elif data[1] == 'cluster2':
            cluster2.append(data)
        else:
            cluster3.append(data)
    clustercenter1 = calculate_mean(cluster1)
    clustercenter2 = calculate_mean(cluster2)
    clustercenter3 = calculate_mean(cluster3)
    return (clustercenter1, clustercenter2, clustercenter3)


def calculate_mean(cluster):
    """Get the mean and take it as new center"""
    a, b, c, d = 0, 0, 0, 0
    total = len(cluster)
    for data in cluster:
        a += data[0][0]
        b += data[0][1]
        c += data[0][2]
        d += data[0][3]
    new_center = [a / total, b / total, c / total, d / total]
    return new_center

def main():
    """main function for this method"""

    # 0. initial data k , count ,data_path
    data_path="iris.data";
    k = 3
    count = 0

    # 1. load the set of iris data from the data file
    data_list, ranging = load_data(data_path)

    # 2. load the random set cluster_center_list
    cluster_center_list = random.sample(data_list, k)

    # 3. give cluster_center list
    print(cluster_center_list)
    clustercenter1 = cluster_center_list[0][0]
    clustercenter2 = cluster_center_list[1][0]
    clustercenter3 = cluster_center_list[2][0]

    # 4. run k_mean_cluster
    k_mean_cluster(data_list, ranging, clustercenter1, clustercenter2, clustercenter3, count)

# ==================================================================

if __name__ == "__main__":
  main()

