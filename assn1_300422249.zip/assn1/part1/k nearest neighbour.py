"""
Assignment 1  K Nearest Neighbour
Author: Aaron Lee
Student Id: 300422249
"""

def load_data(trainingfile, testfile):
    # Data processing : make the training.txt and test.txt easy to use

    #training data processing
    training_set = open(trainingfile)
    training_data_line = training_set.readlines()
    training_data_line.pop(-1)
    training_set.close()
    training_data_list = []
    temp1 = []
    temp2 = []
    temp3 = []
    temp4 = []

    # list training_data
    for line in training_data_line:
        line.replace("\n", "")
        train_data = line.split()

        a1 = float(train_data[0])
        a2 = float(train_data[1])
        a3 = float(train_data[2])
        a4 = float(train_data[3])
        training_data_list.append(([a1, a2, a3, a4], train_data[4]))
        temp1.append(a1)
        temp2.append(a2)
        temp3.append(a3)
        temp4.append(a4)
    r1 = max(temp1) - min(temp1)
    r2 = max(temp2) - min(temp2)
    r3 = max(temp3) - min(temp3)
    r4 = max(temp4) - min(temp4)
    ranging = [r1, r2, r3, r4]

    # test data load
    testing_set = open(testfile)
    testing_data_line = testing_set.readlines()
    testing_data_line.pop(-1)
    testing_set.close()
    testing_data_list = []

    for line in testing_data_line:
        line.replace("\n", "")
        test_data = line.split()
        testing_data_list.append(([float(test_data[0]), float(test_data[1]), float(test_data[2]), float(test_data[3])], test_data[4]))

    return (training_data_list, testing_data_list, ranging)


def distance_measure(v1, v2, r1, r2, r3, r4):
    #Distance measure (Euclidean distance)
    distances = (((v1[0] - v2[0])/r1)**2 + ((v1[1] - v2[1])/r2)**2 + ((v1[2] - v2[2])/r3)**2 +((v1[3] - v2[3]) / r4) ** 2) ** 0.5
    return distances


def knn_classifier(training_data_list, testing_data_list, ranging, k):
    # predict label for each object in test data based on k nearest neighbour
    total = len(testing_data_list)
    correct = 0

    # 3. compare each test object with all training objects
    for test in testing_data_list:
        temp = []
        for train in training_data_list:
            distance = distance_measure(train[0], test[0], ranging[0], ranging[1], ranging[2], ranging[3])
            temp.append((distance, train[1]))
        temp1 = sorted(temp, key=lambda s: s[0])

        #4. get the k nearest neighbour
        distance_list = temp1[:k]
        label_list = []

        #5. predict label based on k nearest neighbour
        for i in distance_list:
            label_list.append(i[1])

        if len(label_list) == 1:
            predict_label = label_list[0]

        else:
            count1 = label_list.count("Iris-setosa")
            count2 = label_list.count("Iris-versicolor")
            count3 = label_list.count("Iris-virginica")
            max_value = max(count1, count2, count3)
            if count1 == max_value:
                predict_label = "Iris-setosa"
            elif count2 == max_value:
                predict_label = "Iris-versicolor"
            else:
                predict_label = "Iris-virginica"

        # 6.calculate the accuracy
        if predict_label == test[1]:
            correct += 1
            print(predict_label+": correct")
        else:
            print(predict_label+": incorrect")
    accuracy = "{:.2f}%".format((float(correct) / float(total)) * 100)
    # 7.print k and the accuracy
    print("when k = " + str(k) + ", accuracy is " + accuracy)


def main():
    # 1. load the set of iris data from the data file
    training_data_list, testing_data_list, tempArrary= load_data("iris-training.txt", "iris-test.txt")

    # 2. run for knn_classifier( training_data_list,testing_data_list,tempArrary)
    for i in range(1,11):
      print("*************************************************")
      knn_classifier(training_data_list, testing_data_list, tempArrary, i)


# ==================================================================

if __name__ == "__main__":
  main()

