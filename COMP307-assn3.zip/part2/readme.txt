NaiveBayesProgram.py
To compile and execute the program environment:

-Pycharm 2018.3.5  (Python 3.6)  jre:1.8
* the data files are in the code files:
spamLabelled.dat
spamUnlabelled.dat

