"""
Code for COMP307 assignment 3
Part 2: Naive Bayes Method
Author: Aaron Lee
Date: 12/05/2019
Student Id: 300422249
"""
def data_process(labelledfile, unlabelledfile):
    """Process the labelled data and unlabelled data"""
    trainfiledata = open(labelledfile)
    traindata = trainfiledata.readlines()
    trainfiledata.close()
    testfiledata = open(unlabelledfile)
    testdata = testfiledata.readlines()
    trainfiledata.close()

    traindata_list = []
    for line in traindata[:]:
        if line != '\n':
            obj = line.split()
            attributes = []
            for i in range(12):
                attributes.append(obj[i])
            traindata_list.append([attributes, obj[12]])

    testdata_list = []
    for line in testdata[:]:
        if line != '\n':
            obj = line.split()
            attributes = []
            for i in range(12):
                attributes.append(obj[i])
            testdata_list.append(attributes)

    return (traindata_list, testdata_list)

def spamcount(data):
    """Calculate the P(c)"""
    spam = 0
    nospam = 0
    for instance in data:
        if instance[1] == '0':
            nospam += 1
        else:
            spam += 1
    return(spam, nospam)

def likelihood(data, spam, nospam):
    """Calculate probabilities (P(Fi|c) for each feature i"""
    """calcultate count for each feature i, and get P(Fi|C)"""
    zerocount = 0
    prob = []
    count_list = []
    for i in range(12):
        st = 0 #spam (label = 1) and true (value = 1)
        sf = 0 #spam (label = 1) and false (value = 0)
        nt = 0 #nospam (label = 0) and false (value = 1)
        nf = 0 #nospam (label = 0) and false (value = 0)
        for instance in data:
            if instance[1] == '1' and instance[0][i] == '1':
                st += 1
            if instance[1] == '1' and instance[0][i] == '0':
                sf += 1
            if instance[1] == '0' and instance[0][i] == '1':
                nt += 1
            if instance[1] == '0' and instance[0][i] == '0':
                nf += 1
        if st == 0 or sf == 0 or nt == 0 or nf ==0:
            zerocount += 1
        count_list.append([st, sf, nt, nf])
        # nospam_list.append([])
        prob.append([float(st) / spam, float(sf) / spam, float(nt) / nospam, float(nf) / nospam])

    """if any feature count is 0, then add 1 to all count, and re calculate the prob"""
    if zerocount > 0:
        spam += 1
        nospam += 1
        new_count_list = []
        new_prob = []
        for i in count_list:
            i[0] += 1
            i[1] += 1
            i[2] += 1
            i[3] += 1
            new_count_list.append([i[0], i[1], i[2], i[3]])
            new_prob.append([float(i[0]) / spam, float(i[1]) / spam, float(i[2]) / nospam, float(i[3]) / nospam])
        count_list = new_count_list
        prob = new_prob
    for i in range(12):
        print("P(F{} = 1| C = 1) = {}".format(i, prob[i][0]))
        print("P(F{} = 0| C = 1) = {}".format(i, prob[i][1]))
        print("P(F{} = 1| C = 0) = {}".format(i, prob[i][2]))
        print("P(F{} = 0| C = 0) = {}".format(i, prob[i][3]))
        print("\n")
    return (count_list, prob, spam, nospam)


def classifier(data, prob, spam, nospam):
    """clssify label using NBM"""
    for instance in data:
        a = float(spam) / (spam + nospam)
        b = float(nospam) / (spam + nospam)
        for i in range(12):
            if instance[i] == '1':
                a *= prob[i][0]
                b *= prob[i][2]
            else:
                a *= prob[i][1]
                b *= prob[i][3]
        if a > b:
            print('Score(spam) is {}, Score(non-spam) is {}.'.format(a, b))
            print(instance, 'spam')
        else:
            print('Score(spam) is {}, Score(non-spam) is {}.'.format(a, b))
            print(instance, 'nospam')


def main():
    """1.  Gets the job done """
    (traindata_list, testdata_list) = data_process("spamLabelled.dat", "spamUnlabelled.dat")

    """2.  Calculate the P(c) """
    spam, nospam = spamcount(traindata_list)

    """3. Calculate probabilities (P(Fi|c) for each feature i"""
    count_list, prob, spam, nospam = likelihood(traindata_list, spam, nospam)

    """4. clssify label using Naive Bayes Method"""
    classifier(testdata_list, prob, spam, nospam)


if __name__ == "__main__":
    main()